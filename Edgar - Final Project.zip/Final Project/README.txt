README
RodriguezEdgarFinalProject
3/10/2024

- When the program starts, the user has the option to pick between 5 buttons.
- 4 buttons belone to a team. Bayern Munich, Barcelona, Liverpool, and Juventus. The last button is used to exit the program.

- When the team button is clicked, a new window will open up. The window contains information related to the team it belongs to. Information included is: Team logo, year founded, league titles, and current record.

- There will be 4 entry boxes: Game date, opponent name, team score, and opponent score.

- The user will fill in the entries. The user can decide if they want to sabe their results by clicking the save data button.

- If the entry fields meet the requirements, the data will be saved to a .txt file

- If the entry fields do not meet the requirements, an error message will be displayed. 

- The user can decide to close the window if they do not want to add the game results to the .txt file. 